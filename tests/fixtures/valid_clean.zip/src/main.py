import sys
from math import sqrt

def calculate_hypotenuse(a: float, b: float) -> float:
    """Calculates hypotenuse safely using standard math."""
    return sqrt(a**2 + b**2)

def main():
    print(f'Hypotenuse 3, 4 = {calculate_hypotenuse(3.0, 4.0)}')

if __name__ == '__main__':
    main()
