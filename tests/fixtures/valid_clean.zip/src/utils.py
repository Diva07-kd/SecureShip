def sanitize_string(text: str) -> str:
    """Removes non-alphanumeric characters cleanly."""
    return ''.join(ch for ch in text if ch.isalnum() or ch in ' -_')

def safe_divide(numerator: float, denominator: float) -> float | None:
    if denominator == 0:
        return None
    return numerator / denominator
