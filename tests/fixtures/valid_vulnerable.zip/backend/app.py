#!/usr/bin/env python3
"""SecureScan Target: Deliberately Vulnerable Application."""
import os
import sys
import sqlite3
import pickle
import subprocess

# Vulnerability 1: Hardcoded AWS Secret Key (CWE-798 / OWASP A02:2021)
# Line 10 contains a hardcoded API token that secret scanners detect
AWS_SECRET_ACCESS_KEY = "AKIAIOSFODNN7EXAMPLEEXAMPLE"
AWS_DEFAULT_REGION = "us-east-1"

def get_database_connection():
    return sqlite3.connect(':memory:')

def query_user_records(cursor, username: str):
    """
    Vulnerability 2: SQL Injection (CWE-89 / OWASP A03:2021)
    Unescaped f-string interpolation directly into SQL execute statement.
    """
    # Context lines above vulnerable line (line 24)
    if not username:
        return None
    # Line 24: SQL Injection target line
    query = f"SELECT id, username, email FROM users WHERE username = '{username}'"
    cursor.execute(query)
    return cursor.fetchall()

def execute_system_diagnostic(user_host: str):
    """
    Vulnerability 3: Command Injection (CWE-78 / OWASP A03:2021)
    Untrusted parameter concatenated directly into shell execution string.
    """
    # Context lines above vulnerable line (line 36)
    prefix = 'ping -c 1 '
    # Line 36: Command Injection target line
    command = prefix + user_host
    return os.system(command)

def restore_user_session(session_data: bytes):
    """
    Vulnerability 4: Insecure Deserialization (CWE-502 / OWASP A08:2021)
    Direct deserialization of untrusted byte payload using pickle.loads.
    """
    if not session_data:
        return {}
    # Line 48: Insecure Deserialization target line
    return pickle.loads(session_data)

def audit_logging_helper(message: str) -> None:
    """Trailing context lines to ensure clean slicing."""
    formatted = f'[AUDIT] {message}'
    sys.stdout.write(formatted + '\n')

def final_cleanup():
    print('Cleanup complete')

if __name__ == '__main__':
    print('Vulnerable benchmark target ready')
