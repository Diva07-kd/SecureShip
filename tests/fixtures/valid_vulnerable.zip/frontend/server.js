// Node.js target with eval code injection (CWE-95)
const http = require('http');
const url = require('url');

const server = http.createServer((req, res) => {
    const parsed = url.parse(req.url, true);
    const userFormula = parsed.query.formula;
    if (userFormula) {
        // Line 9: Code Injection via eval()
        const result = eval(userFormula);
        res.end('Calculated: ' + result);
    } else {
        res.end('Provide ?formula=');
    }
});

server.listen(3000, () => console.log('Listening on 3000'));
